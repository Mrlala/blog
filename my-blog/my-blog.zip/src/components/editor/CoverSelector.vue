<template>
  <div class="action-buttons">
    <button @click="$emit('edit')" class="edit-btn">编辑</button>
    <button @click="confirmDelete" class="delete-btn">删除</button>
  </div>
</template>

<script setup>
import { defineEmits } from 'vue'
const emit = defineEmits(['edit', 'delete'])

function confirmDelete() {
  if (window.confirm('确定删除该文章吗？')) {
    emit('delete')
  }
}
</script>

<style scoped>
.action-buttons {
  display: flex;
  gap: 8px;
}

.edit-btn {
  background: #60a5fa;
  border: none;
  color: white;
  border-radius: 0.4em;
  padding: 0.3em 0.8em;
  cursor: pointer;
}
.edit-btn:hover {
  background: #3b82f6;
}

.delete-btn {
  background: #f87171;
  border: none;
  color: white;
  border-radius: 0.4em;
  padding: 0.3em 0.8em;
  cursor: pointer;
}
.delete-btn:hover {
  background: #ef4444;
}
</style>
