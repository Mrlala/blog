<template>
  <footer class="main-footer">
    <p>© 2025 Your Name. All rights reserved.</p>
    <!-- 你可以放备案/联系方式/社交链接等 -->
  </footer>
</template>

<style>
.main-footer {
  margin-top: 3em;
  padding: 1.2em 0;
  background: #eee;
  color: #666;
  border-radius: 12px;
  text-align: center;
  font-size: 0.98em;
}
</style>
