<template>
  <div class="write-single-col">
    <n-card class="editor-pane" :bordered="false" size="large">
      <TitleInput v-model="title" />

      <TagInput v-model="tags" :max="6" class="mb-block" />

      <SummaryInput v-model="summary" class="mb-block" />

      <MdEditor v-model="content" :theme="theme" style="height: 420px" :show-catalog="true" @onUploadImg="onUploadImage"
        class="mb-block" />

    

      <n-space justify="end" class="mt-2 mb-block">
        <n-button type="primary" :loading="saving" :disabled="!canSave" @click="saveArticle"
          class="save-btn">保存</n-button>
      </n-space>

      <n-alert v-if="msgShow" :type="msgType" class="mt-4 mb-block" show-icon>
        {{ msg }}
      </n-alert>
    </n-card>
  </div>
</template>

<script setup>
import { ref, onMounted, onBeforeUnmount, computed, watch } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { NButton, NCard, NAlert, NSpace } from 'naive-ui'
import TagInput from '@/components/editor/TagInput.vue'
import TitleInput from '@/components/editor/TitleInput .vue'
import SummaryInput from '@/components/editor/SummaryInput.vue'
import { useDraft } from '@/composables/useDraft.js'
import { MdEditor } from 'md-editor-v3'
import 'md-editor-v3/lib/style.css'

const router = useRouter()
const route = useRoute()

const title = ref('')
const content = ref('')
const tags = ref([])
const summary = ref('')
const coverUrl = ref('')
const saving = ref(false)
const msg = ref('')
const msgType = ref('success')
const msgShow = ref(false)
const isEdit = ref(false)
const editFile = ref('')
const tagSuggestions = ref([
  'JavaScript', 'Vue', 'AI', '生活', '前端', '后端',
  '思考', '阅读', '工作', '成长', '算法', '随笔'
])

// 主题变量，默认从 localStorage 读取
const theme = ref(localStorage.getItem('naive-theme') || 'light')

function onThemeChange(event) {
  const newTheme = event.detail
  if (newTheme === 'light' || newTheme === 'dark') {
    theme.value = newTheme
  }
}

onMounted(async () => {
  window.addEventListener('naive-theme-change', onThemeChange)

  const file = route.query.edit
  if (file) {
    isEdit.value = true
    editFile.value = file
    const raw = await fetch(`/articles/${file}`).then(res => res.text())
    const match = raw.match(/^---\n([\s\S]*?)\n---/)
    let t = '', ts = []
    if (match) {
      const front = match[1]
      const titleMatch = front.match(/title:\s*(.+)/)
      t = titleMatch ? titleMatch[1].trim() : ''
      const tagLines = front.split('\n').filter(line => line.trim().startsWith('- '))
      ts = tagLines.map(line => line.replace('- ', '').trim()).filter(Boolean)
    }
    title.value = t
    tags.value = ts
    content.value = raw.replace(/^---[\s\S]*?---/, '').replace(/^# .*\n?/, '').trim()
    showDraftBar.value = false
  } else {
    showDraftBar.value = load()
  }
})

onBeforeUnmount(() => {
  window.removeEventListener('naive-theme-change', onThemeChange)
})

const { draft, load, save, clear } = useDraft()
const showDraftBar = ref(false)

watch([title, content, tags], ([t, c, tg]) => {
  save(t, c, tg)
  showDraftBar.value = !!t || !!c || (tg && tg.length)
})

function restoreDraft() {
  title.value = draft.value.title
  content.value = draft.value.content
  tags.value = draft.value.tags
  showDraftBar.value = false
}
function clearDraft() {
  clear()
  showDraftBar.value = false
}

const canSave = computed(() =>
  title.value.trim() && content.value.trim() && title.value.length <= 60
)

async function saveArticle() {
  if (!canSave.value) {
    msg.value = '标题或内容不合法'
    msgType.value = 'error'
    msgShow.value = true
    setTimeout(() => (msgShow.value = false), 1800)
    return
  }
  saving.value = true
  let front = `---\ntitle: ${title.value}\n`
  if (tags.value.length) {
    front += `tags:\n${tags.value.map(t => '  - ' + t).join('\n')}\n`
  }
  if (summary.value) {
    front += `summary: ${summary.value}\n`
  }
  front += '---\n'
  let mdContent = front + '\n' + content.value
  let filename = ''
  if (isEdit.value && editFile.value) {
    filename = editFile.value
  } else {
    filename = `${new Date().toISOString().slice(0, 10)}-${title.value.trim().replace(/\s+/g, '-')}.md`
  }
  try {
    const res = await fetch('http://localhost:3001/api/article/save', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ filename, content: mdContent, cover: coverUrl.value })
    })
    const data = await res.json()
    if (data.success) {
      clearDraft()
      msg.value = '保存成功！'
      msgType.value = 'success'
      msgShow.value = true
      setTimeout(() => router.push('/'), 800)
    } else {
      msg.value = '保存失败'
      msgType.value = 'error'
      msgShow.value = true
    }
  } catch (e) {
    msg.value = '请求异常'
    msgType.value = 'error'
    msgShow.value = true
  }
  saving.value = false
}

function onUploadImage(files, callback) {
  const file = files[0]
  if (file) {
    const reader = new FileReader()
    reader.onload = e => callback(e.target.result)
    reader.readAsDataURL(file)
  }
}
</script>

<style scoped>
.write-single-col {
  min-height: 100vh;
  background: var(--write-bg-gradient, linear-gradient(135deg, #f8fafb 0%, #f5f8ff 100%));
  padding: 32px 0 64px 0;
}

.editor-pane {
  width: 96vw;
  max-width: 1320px;
  min-width: 320px;
  margin: 0 auto;
  padding: 28px 24px 22px 24px;
  border-radius: var(--card-radius, 20px) !important;
  box-shadow: var(--editor-shadow, 0 4px 24px 0 rgba(60, 110, 255, 0.09), 0 2px 6px rgba(60, 80, 120, 0.06));
  background: var(--card-color, #fff);
  display: flex;
  flex-direction: column;
  height: auto;
}

.mb-block {
  margin-bottom: 1.18em !important;
}

.editor-pane>*:last-child {
  margin-bottom: 0 !important;
}

.title-input {
  font-size: 1.13em !important;
  font-weight: 700;
  border-radius: var(--input-radius, 10px) !important;
  padding: 0.62em 1.15em;
  background: var(--input-bg, #f8faff);
  border: var(--input-border, none);
  color: var(--input-text, #1e293b);
}

.save-btn {
  border-radius: var(--btn-radius, 999px);
  padding-left: 2em;
  padding-right: 2em;
  font-weight: 600;
  font-size: 1.08em;
  letter-spacing: 0.5px;
  box-shadow: var(--btn-shadow, 0 1px 4px rgba(46, 110, 255, 0.05));
  background: var(--btn-bg, linear-gradient(90deg, #75c7fa 0%, #4e8ef7 100%));
  color: var(--btn-text, #fff);
  border: none;
  transition: background 0.2s, filter 0.15s;
}

.save-btn:active {
  filter: brightness(0.97);
}
</style>
